package com.example.management_hospital;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AppointmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        // Get references to the views
        EditText etPatientName = findViewById(R.id.etPatientName);
        EditText etAge = findViewById(R.id.etAge);
        RadioGroup rgGender = findViewById(R.id.rgGender);
        EditText etDisease = findViewById(R.id.etDisease);
        EditText etDoctorName = findViewById(R.id.etDoctorName);
        EditText etDate = findViewById(R.id.etDate);
        EditText etTime = findViewById(R.id.etTime);
        Button btnBookAppointment = findViewById(R.id.btnBookAppointment);

        // Handle button click
        btnBookAppointment.setOnClickListener(v -> {
            String patientName = etPatientName.getText().toString();
            String age = etAge.getText().toString();
            String gender = ((RadioButton) findViewById(rgGender.getCheckedRadioButtonId())).getText().toString();
            String disease = etDisease.getText().toString();
            String doctorName = etDoctorName.getText().toString();
            String date = etDate.getText().toString();
            String time = etTime.getText().toString();

            if (!patientName.isEmpty() && !age.isEmpty() && !gender.isEmpty() && !disease.isEmpty() &&
                    !doctorName.isEmpty() && !date.isEmpty() && !time.isEmpty()) {
                // Process booking (e.g., save to database or send to server)
                Toast.makeText(this, "Appointment booked for " + patientName + " (" + gender + ", " + age + ") with Dr. " + doctorName + " on " + date + " at " + time, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
            }
        });
    }
}